# geeks-bootstrap-5

Geeks Bootstrap 5 Theme

# Geeks Academy Admin Template

FreshCart is beautifully designed, expertly crafted components UI kit for building a high-quality website and web apps using web technologies — HTML, TailwindCSS, and JavaScript — with integrations of the world’s most popular Bootstrap Javascript Plugins .

### Documentation

Development documentation is available at `src/docs/index.html` (or `dist/docs/index.html` once you've compiled), or visit https://geeksui.codescandy.com/geeks/docs/index.html.

### Getting Started

The steps to compile and get started with development are covered in detail in documentation mentioned above, but the summary is:

- npm install -g gulp-cli
- npm install
- gulp

### Support

Codescandy is happy to provide support for issues. Contact us an email at hello@codescandy.com

### Geeks UI Figma 3.1.0

[Geeks UI Figma](https://www.figma.com/file/ZwolZssXCUraAuP0SpjBwg/Geeks-UI---%5B-3.1.0-%5D?type=design&node-id=1887%3A6310&mode=design&t=rNTgLblFgPdyzAw2-1)
